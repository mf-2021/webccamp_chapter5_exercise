lines = readlines
lines.each do |elem|
  p elem.chomp.split(' ')
end

