# それぞれのメソッドによる標準出力
int = 1000
str = "文字列"
arr = ["a","b","c"]

print "pメソッドの出力\n"
print "-----------------\n"
p int
p str 
p arr 
print "\n"

print "printメソッドの出力\n"
print "-----------------\n"
print int
print str 
print arr
print "\n"
print "\n"

print"putsメソッドの出力\n"
print "-----------------\n"
puts int
puts str 
puts arr