line = gets.split(' ')
p line
