arr = ['A', 'B', 'C']

p arr